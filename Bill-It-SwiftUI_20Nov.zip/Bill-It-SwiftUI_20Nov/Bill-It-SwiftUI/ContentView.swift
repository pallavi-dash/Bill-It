//
//  ContentView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import SwiftUI

struct BillType: Identifiable {
    var id = UUID()
    var billType: String
}

var billType = [
    BillType(billType: "Food"),
    BillType(billType: "Travel")
]

struct BillInfo : Identifiable, Hashable {
    
    let id = UUID()
    
    var date: String?
    var address : String?
    var phoneNumber : String?
    var totalAmount : String?
    var type: String?
    
}

//Variable to store the text of the processed image
var resultingText = ""
var billDetailsArray = [[String:String]]()
var indicatorState = false

struct ContentView: View {
    @ObservedObject var billsVM = BillsViewModel()
    var body: some View {
        
        NavigationView {
            
            BillScanView(billsVM: billsVM)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
