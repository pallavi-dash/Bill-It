//
//  BillDetailsView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import Foundation
import SwiftUI


struct BillDetailsView: View {
    
    @State private var searchQuery: String = ""
    var billingDetail: [BillInfo] = []
    
    var body: some View {
        
        VStack {
            List {
                SearchBar(text: self.$searchQuery)
                ForEach(billingDetail.filter {
                    self.searchQuery.isEmpty ?
                        true :
                        "\($0)".lowercased().contains(self.searchQuery.lowercased())
                }, id: \.self) { bill in
                    BillDetailsCell(bills: bill)
                }
            }
        }
        .navigationBarTitle("Bill Details")
    }
}

struct BillDetailsCell: View {
    let bills : BillInfo
    var body: some View {
            VStack(alignment: .leading) {
                Text("Date: \(bills.date ?? "N/A")")
                Text("Address: \(bills.address ?? "N/A")")
                Text("Phone No: \(bills.phoneNumber ?? "N/A")")
                Text("Amount: \(bills.totalAmount ?? "N/A")")
                Text("Type: \(bills.type ?? "N/A")")
        }
    }
}
