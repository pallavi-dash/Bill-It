import Foundation
import SwiftUI
import Vision
import VisionKit
import Combine


//This variable contains all the bills details in an array.
var allBillsData: [BillInfo] = []

/*
 Class Name: BillsViewModel
 Description: This method detects the scanned image text, and classifiesit into its respective groups.
 */
public class BillsViewModel: ObservableObject {
    
    //this variable is an array of all the scanned bills data.
    @Published var allBills: [BillInfo] = []
    
    //This variable checks whether the activity indicator should be animated or not(animatedf in case of data being fetched)
    @Published var isAnimating : Bool = false
    
    //This variable contains the scanned billed data
    @Published var billsData = BillInfo(date: "N/A", address: "N/A", phoneNumber: "N/A", totalAmount: "N/A", type: "N/A")
    
    /*
     Func Name: readDataFromImage
     Description: Reads data from image and stores it.
     */
    func readDataFromImage(image: UIImage, completionHandler: @escaping (BillInfo?) -> Void) {
        
        let arrayOfAmounts = ["Total Amount", "Amount", "Total", "Total Due"]
        
        var tempArr = [String]()
        
        var nextIndex = 0
        
        //This request recognises the text in given area.
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation] else {
                fatalError("Received invalid observations")
            }
            
            for observation in observations {
                guard let bestCandidate = observation.topCandidates(1).first else {
                    print("No candidate")
                    continue
                }
                
                do {
                    let detector = try NSDataDetector(types: NSTextCheckingAllTypes)
                    let range = NSRange(bestCandidate.string.startIndex..<bestCandidate.string.endIndex, in: bestCandidate.string)
                    detector.enumerateMatches(in: bestCandidate.string,
                                              options: [],
                                              range: range) { (match, flags, _) in
                                                guard let match = match else {
                                                    return
                                                }
                                                
                                                switch match.resultType {
                                                //Stores the date from the detected text
                                                case .date:
                                                    resultingText += "Bill Date: \(bestCandidate.string)" + "\n"
                                                    if flags == .hitEnd {
                                                        DispatchQueue.main.async {
                                                            self.billsData.date = bestCandidate.string
                                                        }
                                                    }
                                                //Stores the phone number from the detected text
                                                case .phoneNumber:
                                                    //resultingText += "Phone Number: \(bestCandidate.string)" + "\n"
                                                    DispatchQueue.main.async {
                                                        self.billsData.phoneNumber = bestCandidate.string
                                                    }
                                                //Stores the address from the detected text
                                                case .address:
                                                    //resultingText += "Address: \(bestCandidate.string)" + "\n"
                                                    DispatchQueue.main.async {
                                                        self.billsData.address = bestCandidate.string
                                                    }
                                                default:
                                                    return
                                                }
                                                
                    }
                    
                    
                    tempArr.append(bestCandidate.string)
                } catch {
                    print("handle error")
                }
            }
            
            for (_, item) in arrayOfAmounts.enumerated() {
                
                for (indexOfTemp, itemOfTemp) in tempArr.enumerated() {
                    let newTempString = itemOfTemp.replacingOccurrences(of: ":", with: "").lowercased()
                    if newTempString.contains(item.lowercased()) {
                        nextIndex = indexOfTemp
                        break
                    }
                }
            }
            
            for item in nextIndex...tempArr.count {
                if tempArr[item].rangeOfCharacter(from: NSCharacterSet.decimalDigits) != nil {
                    nextIndex = item
                    break
                }
            }
            
            //Stores the total amount from the detected text
            //resultingText += "Total amount: \(tempArr[nextIndex])"
            if tempArr.count > 0 {
                DispatchQueue.main.async {
                    self.billsData.totalAmount = tempArr[nextIndex].trimmingCharacters(in: CharacterSet.decimalDigits.inverted)
                }
            }
        }
        
        //The request recognition level is set to accurate, and it detects the elements to an almost accurate result. Detection takes more time than .fast.
        request.recognitionLevel = .accurate
        request.customWords = arrayOfAmounts
        let requests = [request]
        
        //If no image is found, error is thrown
        DispatchQueue.global(qos: .userInitiated).async {
            guard let img = image.cgImage else {
                fatalError("Missing image to scan")
            }
            
            let handler = VNImageRequestHandler(cgImage: img, options: [:])
            do {
                
                try handler.perform(requests)
            } catch {
                
                print(error)
            }
            
            // resultingText += "\n\n"
            
            DispatchQueue.main.async
                {
                    self.isAnimating = false
                    completionHandler(self.billsData)
            }
        }
    }
}

/*
 Func Name: HomePageView
 Description: UI of the home page
 */
struct HomePageView: View {
    
    @Binding var showImagePicker: Bool
    @Binding var image: UIImage?
    @Binding var menuOpen: Bool
    @Binding var showAddView: Bool
    
    var body: some View {
        ZStack {
            VStack {
                ZStack {
                    Image("scan")
                    Image("barcode")
                }
                .padding()
                .padding(.leading,CGFloat(12))
                .padding(.top,CGFloat(100))
                
                Text("Scan Bill")
                    .foregroundColor(.blue)
                
                HStack {
                    Button(action: {
                        self.showImagePicker = true
                        
                    }) {
                        Image(systemName: "photo.fill").renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                    }
                    .padding()
                    .padding(.leading,CGFloat(12))
                    //.padding(.top,CGFloat(30))
                    
                    Button(action: {
                        self.showImagePicker = true}) {
                            Image(systemName: "camera").renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                    }
                    .padding()
                    .padding(.leading,CGFloat(12))
                    //.padding(.top,CGFloat(30))
                }
                
                Text("Bill-IT")
                    .foregroundColor(Color.blue)
                    .padding()
                    .padding(.top,CGFloat(250))
                    .padding(.leading,CGFloat(12))
                    .font(.title)
            }
            
            SideMenu(width: 270,
                     isOpen: self.menuOpen,
                     menuClose: self.openMenu)
            
        }
            
        .navigationBarItems(leading:
            
            ZStack {
                if !self.menuOpen {
                    Button(action: {
                        self.openMenu()
                    }, label: {
                        Image(systemName: "line.horizontal.3")
                        //Image(systemName: "photo.fill")
                    })
                }
            },
                            
                            trailing: ZStack {
                                Button(action: { self.showAddView.toggle() }) { Text("Show") }
                                    .actionSheet(isPresented: $showAddView) {
                                        ActionSheet(title: Text(""))
                                }
            }
        )
    }
    
    func openMenu() {
        self.menuOpen.toggle()
    }
    
    func openAddMenu() {
        self.showAddView.toggle()
    }
}

/*
 Func Name: EditPageView
 Description: UI of the edit page.
 */
struct EditPageView: View {
    
    @State var value = billType
    @State var billCategory = ["Food", "Travel"]
    @Binding var image: UIImage?
    @Binding var selectedType: Int
    @ObservedObject var billsVM: BillsViewModel
    @State var addCategory: String = ""
    @State private var showAlert = false
    
    var alert: Alert {
        Alert(title: Text("Alert"), message: Text("Category added successfully."), dismissButton: .default(Text("Dismiss")))
    }
    
    var body: some View {
        
        VStack {
            if self.image != nil {
                Form {
                    Image(uiImage: self.image!)
                        .resizable().scaledToFit()
                    
                    Section(header: Text("Add Category:")) {
                        HStack {
                            TextField("", text: $addCategory)
                                .border(Color(UIColor.lightGray))
                                .frame(width: 330, height: 30, alignment: .leading)
                            Button("Add", action: {
                                self.billCategory.append(self.addCategory)
                                billType.append(BillType(billType: self.addCategory))
                                self.addCategory = ""
                                self.showAlert.toggle()
                            })
                            .alert(isPresented: $showAlert, content: { self.alert })
                        }
                    }
                    
                    Section(header: Text("Select Category:")){
                        HStack {
                            Picker(selection: self.$selectedType, label: Text("")){
                                ForEach(0 ..< self.billCategory.count,id: \.self) {
                                    Text(self.billCategory[$0])
                                }
                            }
                        }
                    }
                    .fixedSize()
                }
            }
        }
        .navigationBarItems(leading: Button("Save Details",
                                            action: {
                                                //On save the bill data is updated.
                                                self.billsVM.billsData = BillInfo(date: self.billsVM.billsData.date,
                                                                                  address: self.billsVM.billsData.address, phoneNumber: self.billsVM.billsData.phoneNumber, totalAmount: self.billsVM.billsData.totalAmount, type: self.billCategory[self.selectedType])
                                                allBillsData.append(self.billsVM.billsData)
                                                self.image = nil
                                                
        })
            .opacity(1.0),
                            trailing: Button("Cancel", action: {
                                self.image = nil
                            })
                                .opacity(1.0))
        
        
    }
}

/*
 Func Name: BillScanView
 Description: UI of the pages in the app
 */
struct BillScanView:  View {
    
    @ObservedObject var billsVM = BillsViewModel()
    
    @State private var showImagePicker: Bool = false
    @State private var image: UIImage? = nil
    
    var billCategory = ["Food", "Travel"]
    
    @State private var showSheet = false
    @State private var selectedType = 0
    @State private var tapOnSave = false
    @State var menuOpen: Bool = false
    @State var showAddView = false
    
    var body: some View {
        
        ZStack {
            
            VStack {
                
                if image == nil {
                    HomePageView(showImagePicker: $showImagePicker, image: $image, menuOpen: $menuOpen, showAddView: $showAddView)
                } else {
                    EditPageView(image: $image, selectedType: $selectedType, billsVM: billsVM)
                }
            }
            
            if billsVM.isAnimating {
                VStack {
                    ActivityIndicator(isAnimating: .constant(true), style: .large)
                    Text("Loading...")
                        .font(.custom("TimesNewRomanPS-BoldMT", size: 14.0))
                }
                .frame(width: 120, height: 120, alignment: .center)
                .background(Color.secondary.colorInvert())
                .foregroundColor(Color.primary)
                .cornerRadius(20)
            }
        }
            
        .sheet(isPresented: self.$showImagePicker, onDismiss: {
            
            self.billsVM.isAnimating = true
            
            self.billsVM.readDataFromImage(image: self.image!) {str in
                self.billsVM.billsData = BillInfo(date: str?.date,
                                                  address: str?.address,
                                                  phoneNumber: str?.phoneNumber,
                                                  totalAmount: str?.totalAmount,
                                                  type: str?.type)
            }
        }) {
            //The photo gallery is opened
            PhotoCaptureView(showImagePicker: self.$showImagePicker, image: self.$image)
        }
    }
}


/*
 Func Name: MenuContent
 Description: UI of the menu content of the side menu
 */
struct MenuContent: View {
    
    var body: some View {
        VStack {
            List {
                VStack {
                    Image(systemName: "person.crop.circle.fill").resizable()
                        .frame(width: 60.0, height: 60.0).padding()
                        .padding(.leading,CGFloat(80))
                        .padding(.top,CGFloat(60))
                    Text("User")
                        .foregroundColor(Color.blue)
                        .padding(.leading,CGFloat(80))
                        .font(.headline)
                }
                NavigationLink(destination: BillCategoryView(), label: {
                    Text("Show bills").foregroundColor(Color.blue)
                })
                Text("Settings").foregroundColor(Color.blue)
            }
            .colorMultiply(Color.init(UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1)))
        }
    }
}

/*
 Func Name: SideMenu
 Description: UI of the side menu
 */
struct SideMenu: View {
    let width: CGFloat
    let isOpen: Bool
    let menuClose: () -> Void
    
    var body: some View {
        ZStack {
            GeometryReader { _ in
                EmptyView()
            }
            .background(Color.white.opacity(0.3))
            .opacity(self.isOpen ? 1.0 : 0.0)
            .animation(Animation.easeIn.delay(0.25))
            .onTapGesture {
                self.menuClose()
            }
            
            HStack {
                MenuContent()
                    .frame(width: self.width)
                    .background(Color.white)
                    .offset(x: self.isOpen ? 0 : -self.width)
                    .animation(.default)
                
                Spacer()
            }
        }
    }
}


struct AddView: View {
    //@Binding var showAddView: Bool
    @Binding var showImagePicker: Bool
    var body: some View {
        VStack {
            List {
                Button(action: {
                    self.showImagePicker = true
                }) {
                    Text("Choose Photo")
                }
            }
            .colorMultiply(Color.init(UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1)))
        }
    }
}


/*
 Func Name: SideMenu
 Description: UI of the side menu
 */
struct TopMenu: View {
    let height: CGFloat
    let isOpen: Bool
    let menuClose: () -> Void
    
    @Binding var showImagePicker: Bool
    
    var body: some View {
        ZStack {
            GeometryReader { _ in
                EmptyView()
            }
            .background(Color.white.opacity(0.3))
            .opacity(self.isOpen ? 1.0 : 0.0)
            .animation(Animation.easeIn.delay(0.25))
            .onTapGesture {
                self.menuClose()
            }
            
            HStack {
                AddView(showImagePicker: $showImagePicker)
                    .frame(width: 600, height: 300)
                    .background(Color.white)
                    .offset(x: 0, y: self.isOpen ? -400 : -800)
                    .animation(.default)
                
                Spacer()
            }
        }
    }
}


