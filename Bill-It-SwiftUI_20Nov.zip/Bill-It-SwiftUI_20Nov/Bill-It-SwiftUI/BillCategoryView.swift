//
//  BillCategoryView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import Foundation
import SwiftUI
import Vision
import VisionKit



var selectedType:String = "Food"
struct BillCategoryView: View {
    
    @State private var searchQuery: String = ""
    @Environment(\.presentationMode) private var isPresented
    var body: some View {
        
        VStack {
            List(billType) { bill in
                BillCategoryCell(billType: bill)
            }
        }
        .navigationBarTitle("Bill Category")
    }
    func dismiss() {
        isPresented.wrappedValue.dismiss()
    }
}

struct BillCategoryCell: View {
    let billType : BillType
    var body: some View {
        VStack(alignment: .leading) {
            NavigationLink(destination: BillDetailsView(billingDetail: allBillsData.filter{$0.type == billType.billType})) {
                Text(billType.billType)
            }
        }
    }
}

